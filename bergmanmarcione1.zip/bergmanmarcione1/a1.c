/*
	a1.c

	Malachi Bergman
	Koal Marcione
	10/19/2022


	A1
	CS451 w/ Dr.Kanche Fall 2022

	list process IDs and their children given a root process ID

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include "queue.h"
#include "process.h"

#define PID_SIZE 10

void printPID(char *pid, int level, char *children);

char * getNextPID(char **s);

/* 
	main(int argc, char **argv)

	list process IDs and their children given a root process ID
*/
void main(int argc, char **argv){
	char *pid = argv[1];

	char folder[12] = "/proc/";
	strcat(folder, pid);
    struct stat sb;

    if (!(stat(folder, &sb) == 0 && S_ISDIR(sb.st_mode))) {
    	printf("Error: %s is not a valid process ID.\n", pid);
        return;
    } 

	Queue *queue  = createQueue();

	enqueue(queue, createProcess(pid, 0));

	while(queue->size > 0){

		Process *process = dequeue(queue);

		char *children = getChildren(process);

		printPID(process->pid, process->level, children);

	    char *child;

	    while((child = getNextPID(&children)) != NULL){
	        enqueue(queue, createProcess(child, process->level + 1));
	    }

	    free(process);

	}

	freeQueue(queue);

	return;
}

/*
	printPID(char *pid, int level, char *children)

	*pid - pid of the process
	level - amount to indent
	*children - list of all children of the process

	outputs the formatted string for given process

*/
void printPID(char *pid, int level, char *children){
	// provide the indentation
	printf("%.*s", level * 3, "                                                ");
	// PID information print to command line
	printf("Children of %s: %s\n", pid, children);

}

/*
	getNextPID(char **s)

	**s - the pointer to the pointer to the string of remaining children

	returns *childPID - the first pid in the list of children
*/
char * getNextPID(char **s){
	// check if there are no more PIDs
	if(**s == '\0'){
		return NULL;
	}

	static char *childPID;
	childPID = (char *) malloc(PID_SIZE);

	int pid_len = 0;
	char *start = *s;

	// count how many characters are in the PID
	while(**s != ' ' && **s != '\0'){
		(*s)++;
		pid_len++;
	}

	// skip over spaces found for next PID
	if(**s == ' '){
		(*s)++;
	}
	
	// make a copy of the child PID value from the list of PIDs
	if(pid_len){
		memcpy(childPID, start, pid_len);
		return childPID;
	}
}