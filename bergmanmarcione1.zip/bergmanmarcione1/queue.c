/*
	queue.c

	Malachi Bergman
	Koal Marcione
	10/19/2022

*/

#include <stdlib.h>
#include "queue.h"

/*
	createQueue()

	returns *q - the new created Queue
*/
Queue* createQueue() {
	Queue *q = malloc(sizeof(Queue));

	if (q == NULL) {
		return q;
	}

	q->size = 0;
	q->head = NULL;
	q->tail = NULL;

	return q;
}

/*
	enqueue(Queue *q, void *data)

	*q - pointer to the Queue to add Node with data
	*data - pointer to data to add to Queue

	returns current size of Queue (see *q)
*/
int enqueue(Queue *q, void *data) {

	Node *node = malloc(sizeof(Node));

	if (node == NULL) {
		return q->size;
	}

	node->data = data;
	node->next = NULL;

	if (q->head == NULL) {
		q->head = node;
		q->tail = node;
		q->size = 1;

		return q->size;
	}


	q->tail->next = node;
	q->tail = node;
	q->size += 1;

	return q->size;
}

/*
	dequeue(Queue *q)

	*q - pointer to the Queue to extract data from first Node

	returns *data - pointer to data in first node
*/
void * dequeue(Queue *q) {
	if (q->size == 0) {
		return NULL;
	}

	void *data = NULL;
	Node *temp = NULL;

	data = q->head->data;
	temp = q->head;
	q->head = q->head->next;
	q->size -= 1;
	free(temp);

	return data;
}

/*
	freeQueue(Queue *q)

	*q - pointer to Queue to free memory

	frees memory of all data in Nodes, memory of Nodes, and memory of the Queue
*/
void freeQueue(Queue *q) {
	if (q == NULL) {
		return;
	}

	while (q->head != NULL) {
		Node *temp = q->head;
		q->head = q->head->next;
		if (temp->data != NULL) {
			free(temp->data);
		}

		free(temp);
	}

	if (q->tail != NULL) {
		if (q->tail->data != NULL) {
			free(q->tail->data);
		}
		free(q->tail);
	}

	free (q);
}