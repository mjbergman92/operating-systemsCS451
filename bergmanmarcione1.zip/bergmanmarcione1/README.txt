Malachi Bergman
Koal Marcione
10/19/2022

A1 
CS 451 Dr.Kanche Fall 2022

This program outputs all the the current running processes and their children recursively
on a linux machine

to compile, run:

gcc a1.c process.c queue.c -o mypstree

after compiling, run in terminal:

./mypstree <process id (must be an int)>

this returns the cascading list of pids and their children

Limitations:
You have to enter a valid pid.
You might be able to get past the error check for valid pid if you enter one of the folder names in /proc
there might be possible memory leaks, although we have written the code to mitigate memory leaks as much we reasoned
