/*
	process.c

	Malachi Bergman
	Koal Marcione
	10/19/2022

*/

#include <stdlib.h>
#include <stdio.h>
#include "process.h"

#define DYN_SIZE 10
#define PATH_SIZE 40

/*
	createProcess(char *pid, int level)

	char *pid : the "process identification number" of the desired process
	int level : the level of indentation (nested childness)

	returns a new process struct
*/
Process * createProcess(char *pid, int level){
	Process *p = malloc(sizeof(Process));

	if(p == NULL){
		return p;
	}

	p->pid = pid;
	p->level = level;

	return p;
}

/*
	getChildren(Process *p)

	Process *p : the process of which to find children

	returns the file contents of the children file of 
	the given process (see *p).
*/
char * getChildren(Process *p){

		// string of children must be static in order to pass back
		static char *children;
		children = (char *) malloc(DYN_SIZE);

		// construct the file path to the children file of the PID
		char path[PATH_SIZE];
		sprintf(path, "/proc/%s/task/%s/children", p->pid, p->pid);
		// open the children file
		FILE *fp = fopen(path, "r");
		 
		char c;
		int i;

		// read in the children file, dynamically allocating memory 
		for(i = 0;(c = fgetc(fp)) != EOF;i++){
			if(i % DYN_SIZE == DYN_SIZE - 1){
				children = (char *) realloc(children, i + 1 + DYN_SIZE);
			}

			children[i] = c;

		}

		// end the char array so it can be read as a string
		children[i] = '\0';

		fclose(fp);

		return children;
}