/*
	process.h

	Malachi Bergman
	Koal Marcione
	10/19/2022

*/

/*
	Process

	*pid - process id of process
	level - the level of "nested childness" of a process

	Info about a Process
*/
typedef struct Process {
	char *pid;
	int level;
} Process;

#ifndef PROCESS_H_
#define PROCESS_H_

Process * createProcess(char *pid, int level);
char * getChildren(Process *p);

#endif