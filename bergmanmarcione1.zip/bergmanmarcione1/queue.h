/*
	queue.h

	Malachi Bergman
	Koal Marcione
	10/19/2022

*/

/*
	Node

	*data - pointer to data
	*next - pointer to next Node

	Node in a Queue
*/
typedef struct Node {
	void *data;
	struct Node *next;
} Node;

/*
	Queue

	size - the current size of the Queue
	*head - pointer to the first Node
	*tail - pointer to the last Node

	Queue of Linked Nodes
*/
typedef struct Queue {
	int size;
	Node *head;
	Node *tail;
} Queue;

#ifndef QUEUE_H_
#define QUEUE_H_

Queue * createQueue();

int enqueue(Queue *q, void *data);

void * dequeue(Queue *q);

void freeQueue(Queue *q);

#endif